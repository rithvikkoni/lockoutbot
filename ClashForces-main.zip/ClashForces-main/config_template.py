#your config.py should look like this
BOT_TOKEN = "YOUR_DISCORD_BOT_TOKEN"
